class CiscomationLoginFailed(Exception):
    '''
    Used when authentication is unsuccessful
    '''
    pass


class CiscomationException(Exception):
    '''
    Used for general purpose
    '''
    pass
